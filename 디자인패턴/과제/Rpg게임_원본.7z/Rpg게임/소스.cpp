#include "Mecro.h"
#include "GameManager.h"

void main()
{
    _CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CRTDBG_ALLOC_MEM_DF);

    //_crtBreakAlloc = 687;
	GameManager Game;
	srand(time(NULL));
	Game.Start();

	/*
	���� ��� ������
	���� ��ų Ȯ�� ���� CLASS���� ����
	�޸� ����
	���� ���� �� �ʱ�ȭ==
	*/

    /*{1327} normal block at 0x00000000000D1930, 16 bytes long.
 Data: <p               > 70 FD 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{1326} normal block at 0x00000000000CFD60, 104 bytes long.
 Data: <                > FF FF FF FF CD CD CD CD CD CD CD CD CD CD CD CD 
{692} normal block at 0x00000000000D1C50, 16 bytes long.
 Data: <                > 10 FC 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{691} normal block at 0x00000000000CFC00, 104 bytes long.
 Data: <                > 06 00 00 00 CD CD CD CD CD CD CD CD CD CD CD CD 
{677} normal block at 0x00000000000D1C00, 16 bytes long.
 Data: <`               > 60 FB 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{676} normal block at 0x00000000000CFB50, 104 bytes long.
 Data: <                > 05 00 00 00 CD CD CD CD CD CD CD CD CD CD CD CD 
{662} normal block at 0x00000000000D1BB0, 16 bytes long.
 Data: <                > B0 FA 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{661} normal block at 0x00000000000CFAA0, 104 bytes long.
 Data: <                > 04 00 00 00 CD CD CD CD CD CD CD CD CD CD CD CD 
{647} normal block at 0x00000000000D1B60, 16 bytes long.
 Data: <                > 00 FA 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{646} normal block at 0x00000000000CF9F0, 104 bytes long.
 Data: <                > 03 00 00 00 CD CD CD CD CD CD CD CD CD CD CD CD 
{632} normal block at 0x00000000000D1A20, 16 bytes long.
 Data: <P               > 50 F9 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{631} normal block at 0x00000000000CF940, 104 bytes long.
 Data: <                > 02 00 00 00 CD CD CD CD CD CD CD CD CD CD CD CD 
{617} normal block at 0x00000000000D1B10, 16 bytes long.
 Data: <                > A0 F8 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{616} normal block at 0x00000000000CF890, 104 bytes long.
 Data: <                > 01 00 00 00 CD CD CD CD CD CD CD CD CD CD CD CD 
{603} normal block at 0x00000000000D1A70, 16 bytes long.
 Data: <                > F0 F7 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{602} normal block at 0x00000000000CF7E0, 104 bytes long.
 Data: <                > FF FF FF FF CD CD CD CD CD CD CD CD CD CD CD CD 
{169} normal block at 0x00000000000C7880, 16 bytes long.
 Data: <@               > 40 94 0C 00 00 00 00 00 00 00 00 00 00 00 00 00 
{168} normal block at 0x00000000000C9440, 64 bytes long.
 Data: < x      NULL    > 80 78 0C 00 00 00 00 00 4E 55 4C 4C 00 CD CD CD */
}
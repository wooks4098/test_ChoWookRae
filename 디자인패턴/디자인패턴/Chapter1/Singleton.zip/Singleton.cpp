#include "Singleton.h"



Singleton::Singleton()
{
}


Singleton::~Singleton()
{
}

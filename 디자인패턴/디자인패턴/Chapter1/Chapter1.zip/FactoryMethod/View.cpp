#include "View.h"

MyView::MyView()
{
	cout << "Create MyView" << endl;
}

MyView::~MyView()
{
	cout << "Destory MyView" << endl;
}

void MyView::Render()
{
	cout << "Render MyView" << endl;
}

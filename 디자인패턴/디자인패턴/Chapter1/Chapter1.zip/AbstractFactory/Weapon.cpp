#include "Weapon.h"

/* Sword */
bool Sword::Attack()
{
	cout << "��!" << endl << endl;

	return true;
}

/* Bow */
bool Bow::Attack()
{
	cout << "����~" << endl << endl;

	return true;
}

/* Staff. */
bool Staff::Attack()
{
	cout << "�Ҷ��~^" << endl << endl;

	return true;
}
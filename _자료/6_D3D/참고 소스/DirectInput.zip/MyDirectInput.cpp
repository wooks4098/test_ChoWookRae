#include "MyDirectInput.h"
#pragma comment(lib, "dxguid.lib")

#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p) = 0; } }

CDirectInput::CDirectInput() : 
	m_pDirectInput(0),
	m_pMouseDevice(0),
	m_MouseState(),
	m_ptMouse(),
	m_lMouseWheel(0),
	m_pKeyboardDevice(0),
	m_Keys(),
	m_hWnd()
{}

HRESULT CDirectInput::CreateDevice(const HWND& hWnd)
{
	m_hWnd = hWnd;

	if (FAILED(DirectInput8Create(GetModuleHandle(NULL), DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&m_pDirectInput, NULL))) return E_FAIL;

	// ���콺 ����̽� ����.
	if (FAILED(m_pDirectInput->CreateDevice(GUID_SysMouse, &m_pMouseDevice, NULL))) return E_FAIL;
	if (FAILED(m_pMouseDevice->SetDataFormat(&c_dfDIMouse2))) return E_FAIL;
	if (FAILED(m_pMouseDevice->SetCooperativeLevel(m_hWnd, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND))) return E_FAIL;
	m_pMouseDevice->Acquire();
	
	// Ű���� ����̽� ����.
	if (FAILED(m_pDirectInput->CreateDevice(GUID_SysKeyboard, &m_pKeyboardDevice, NULL))) return E_FAIL;
	if (FAILED(m_pKeyboardDevice->SetDataFormat(&c_dfDIKeyboard))) return E_FAIL;
	if (FAILED(m_pKeyboardDevice->SetCooperativeLevel(m_hWnd, DISCL_NONEXCLUSIVE | DISCL_FOREGROUND))) return E_FAIL;
	m_pKeyboardDevice->Acquire();

	return S_OK;
}

HRESULT CDirectInput::Update()
{
	if (NULL == m_pMouseDevice || NULL == m_pKeyboardDevice) return E_FAIL;

	ZeroMemory(&m_MouseState, sizeof(m_MouseState));
	HRESULT hr = m_pMouseDevice->GetDeviceState(sizeof(m_MouseState), &m_MouseState);
	if (FAILED(hr))
	{
		hr = m_pMouseDevice->Acquire();
		while (DIERR_INPUTLOST == hr)
			hr = m_pMouseDevice->Acquire();

		return E_FAIL;
	}
	m_ptMouse.x = m_MouseState.lX;
	m_ptMouse.y = m_MouseState.lY;

	ZeroMemory(&m_Keys, sizeof(m_Keys));
	hr = m_pKeyboardDevice->GetDeviceState(sizeof(m_Keys), &m_Keys);
	if (FAILED(hr))
	{
		hr = m_pKeyboardDevice->Acquire();
		while (DIERR_INPUTLOST == hr)
			hr = m_pKeyboardDevice->Acquire();

		return E_FAIL;
	}

	return S_OK;
}

VOID CDirectInput::Release()
{
	if (m_pKeyboardDevice) m_pKeyboardDevice->Unacquire();
	SAFE_RELEASE(m_pKeyboardDevice);

	if (m_pMouseDevice) m_pMouseDevice->Unacquire();
	SAFE_RELEASE(m_pMouseDevice);

	SAFE_RELEASE(m_pDirectInput);
}

VOID CDirectInput::OnActivate(const WPARAM& wParam)
{
	if (WA_INACTIVE != wParam && m_pMouseDevice)
	{
		m_pMouseDevice->Acquire();
	}

	if (WA_INACTIVE != wParam && m_pKeyboardDevice)
	{
		m_pKeyboardDevice->Acquire();
	}
}

int CDirectInput::GetWheelState()
{
	int result = 0;
	if (m_lMouseWheel < m_MouseState.lZ)
		result = 1;
	else  if (m_lMouseWheel > m_MouseState.lZ)
		result = -1;

	m_lMouseWheel = m_MouseState.lZ;

	return result;
}
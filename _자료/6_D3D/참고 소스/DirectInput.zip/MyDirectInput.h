#pragma once
#pragma comment(lib, "dinput8.lib")
#include <dinput.h>

class CDirectInput
{
private:
	LPDIRECTINPUT8			m_pDirectInput;

	LPDIRECTINPUTDEVICE8	m_pMouseDevice;
	DIMOUSESTATE2			m_MouseState;
	POINT					m_ptMouse;
	LONG					m_lMouseWheel;

	LPDIRECTINPUTDEVICE8	m_pKeyboardDevice;
	BYTE					m_Keys[256];

	HWND					m_hWnd;

public:
	CDirectInput();
	~CDirectInput() {}

	HRESULT CreateDevice(const HWND& hWnd);
	HRESULT Update();
	VOID	Release();
	VOID	OnActivate(const WPARAM& wParam);

	// Mouse.
	POINT	GetMousePT() const { return m_ptMouse; }
	int		GetWheelState();
	BOOL	LeftDown() const { return (m_MouseState.rgbButtons[0] & 0x80); }
	BOOL	RightDown() const { return (m_MouseState.rgbButtons[1] & 0x80); }
	BOOL	MiddleDown() const { return (m_MouseState.rgbButtons[2] & 0x80); }

	// Keyboard.
	BOOL	KeyDown(const BYTE& key) const { return (m_Keys[key] & 0x80); }
};